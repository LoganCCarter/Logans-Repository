USE [squirrel]
GO

/****** Object:  Table [dbo].[pet]    Script Date: 3/7/2020 12:55:08 PM ******/
DROP TABLE [dbo].[pet]
GO
USE [squirrel]
GO

/****** Object:  Table [dbo].[ptype]    Script Date: 3/7/2020 12:54:02 PM ******/
DROP TABLE [dbo].[ptype]
GO
USE [squirrel]
GO

/****** Object:  Table [dbo].[owner]    Script Date: 3/7/2020 12:55:38 PM ******/
DROP TABLE [dbo].[owner]
GO

/****** Object:  Table [dbo].[owner]    Script Date: 3/7/2020 12:55:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[owner](
	[name] [varchar](255) NULL,
	[Age] [int] NULL,
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_owner] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO



/****** Object:  Table [dbo].[ptype]    Script Date: 3/7/2020 12:54:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ptype](
	[name] [varchar](max) NULL,
	[breed] [varchar](255) NULL,
	[ID] [bigint] IDENTITY(1,1) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO



/****** Object:  Table [dbo].[pet]    Script Date: 3/7/2020 12:55:08 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[pet](
	[name] [varchar](max) NULL,
	[tid] [bigint] NULL,
	[color] [varchar](max) NULL,
	[age] [int] NULL,
	[oid] [bigint] NULL,
	[pid] [bigint] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [PK_pet] PRIMARY KEY CLUSTERED 
(
	[pid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


